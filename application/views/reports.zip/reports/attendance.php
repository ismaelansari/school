
<div class="content-wrapper" style="min-height: 946px;">

    <section class="content-header">
        <h1>
            <i class="fa fa-bus"></i> <?php echo $this->lang->line('transport'); ?></h1>
    </section>
    <!-- Main content -->
    <section class="content"> 
        <?php $this->load->view('reports/_attendance'); ?>
      
    </div>   
</div>  
</section>
</div>
